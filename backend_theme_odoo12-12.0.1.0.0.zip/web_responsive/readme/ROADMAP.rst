* To view the full experience in a device, the page must be loaded with the
  device screen size. This means that, if you change the size of your browser,
  you should reload the web client to get the full experience for that
  new size. This is Odoo's own limitation.
* App navigation with keyboard.
* Make it more beautiful. Maybe OCA-branded?
